<?php
session_start();
require_once('./connect.php');
if(isset($_POST['current']) || isset($_POST['newpass']) || isset($_POST['renewpass'])){
$password = $_POST['current'];
$password = mysql_real_escape_string($password);
$cpassword1 = $_POST['newpass'];
$cpassword2 = $_POST['renewpass'];
$email = $_SESSION['username'];
if (empty($cpassword1)) {
    echo "Data have not been filled completely";
    break;
} else if (empty($cpassword2)) {
    echo "Data have not been filled completely";
    break;
} else if (empty($password)) {
    echo "Data have not been filled completely";
    break;
}
$q = mysql_query("select * from user where username='$email' and password='$password'");
if ($cpassword1 == $cpassword2) {
    if (mysql_num_rows($q) >= 1) {
        $updatepassword = "UPDATE user SET password = '$cpassword1' where username = '$email'";
        $updatequery = mysql_query($updatepassword);
        header('location:login.php?msg=Changed!');
    } else {
        echo "Old password not correctly!";
    }
    
} else {
     echo "Please fill confirm password correctly!";
}
}
?>