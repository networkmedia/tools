<?php
session_start();
require_once("connect.php");
session_start();
$fname = $_POST['fname'];
$fname = mysql_real_escape_string($fname);
$lname = $_POST['lname'];
$lname = mysql_real_escape_string($lname);
$email = $_POST['email'];
$email = mysql_real_escape_string($email);
$username = $_POST['username'];
$username = mysql_real_escape_string($username);
$pass = $_POST['password'];
$pass = mysql_real_escape_string($pass);
$cekuser = mysql_query("SELECT * FROM user WHERE username = '$username'");
$jumlah = mysql_num_rows($cekuser);
$hasil = mysql_fetch_array($cekuser);
if($jumlah == 1){
header('location: registration.php?msg=User is registered.');
} else {
mysql_query("INSERT INTO user (fname, lname, email, username, password, level, balance, uplink) VALUES('$fname','$lname','$email','$username','$pass','Member','0','Free Register')");
header('location: login.php?msg=User has been registered.');
}
?>