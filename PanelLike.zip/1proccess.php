<?php
session_start();
require_once("connect.php");
$usr = $_SESSION['username'];
$query = mysql_query("SELECT * FROM user WHERE username = '$usr'");
$hasil = mysql_fetch_array($query);
$type = $_POST['type'];
$link = $_POST['link'];
$quantity = $_POST['quantity'];
function getrate($xx,$x){
$c1 = $x / 1;
$c2 = $c1 * $xx;
return $c2;
}
function randnum($lenght) {
$char= '1234567890';
$str = '';
for ($i = 0; $i < $lenght; $i++) {
	$pos = rand(0, strlen($char)-1);
	$str .= $char{$pos};
}
return $str;

} if ($type == 17) {
$text = "Instagram Like HQ Server 1 , Instant ( URL Photo )";
$rate = 0.015;
$min = 20;
$max = 50000;
} else if ($type == 15) {
$text = "Instagram Like HQ Server 2 , Instant ( URL Photo )";
$rate = 0.010;
$min = 10;
$max = 5000;
} else if ($type == 52) {
$text = "Instagram Like  Server 3 , Instant , Unlimited Speed 1-10k/Day ( URL Photo )";
$rate = 0.013;
$min = 100;
$max = 1000000;
} else if ($type == 5) {
$text = "Instagram Like HQ Server 4 , Instant , Max 10K ( URL Photo )";
$rate = 0.006;
$min = 20;
$max = 10000;
} else if ($type == 54) {
$text = "Instagram Like Server 5 , Real Like , Active User ( URL Photo )";
$rate = 0.050;
$min = 100;
$max = 20000;
} else if ($type == 50) {
$text = "Instagram Like Server 6 , Arab ( URL Photo )";
$rate = 0.050;
$min = 100;
$max = 1000000;
}
$price = getrate($quantity, $rate);
$no = "MWA - ".randnum(3);
$date = date("d-m-y");
if($hasil['balance'] < $price){
echo "Your balance is less";
} else {
$simpan = mysql_query("INSERT INTO history VALUES('$no','$text | $link | $quantity','$date','$usr','Pending')");
$simpan = mysql_query("UPDATE user SET balance=balance-$price WHERE username = '$usr'");
if ($simpan) {
$x = "http://bulkandcheap.com/api.php";
$api = "5a98aa8815be157a9cc076d001e95d99";
$action = "add";

$c = curl_init();
curl_setopt($c, CURLOPT_URL, $x);
curl_setopt($c, CURLOPT_POST, 1);
curl_setopt($c, CURLOPT_POSTFIELDS, "key=$api&action=$action&link=$link&type=$type&quantity=$quantity");
curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
$result = curl_exec($c);
curl_close($c);

$bhak = json_decode($result, true);
echo "Order Finished!";
}
}
?>