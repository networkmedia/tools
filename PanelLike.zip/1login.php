<?php
session_start();
require_once("connect.php");
session_start();
$username = $_POST['username'];
$username = mysql_real_escape_string($username);
$pass = $_POST['password'];
$pass = mysql_real_escape_string($pass);
$cekuser = mysql_query("SELECT * FROM user WHERE username = '$username'");
$jumlah = mysql_num_rows($cekuser);
$hasil = mysql_fetch_array($cekuser);
if($jumlah == 0) {
header('location: login.php?msg=No user registered.');
} else {
if($pass <> $hasil['password']) {
header('location: login.php?msg=Username or password incorrect.');
} else {
$_SESSION['username'] = $username;
header('location: index.php');
}
}
?>