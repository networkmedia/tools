<?php
$host = "mysql.hostinger.my";
$username = "u156995236_vip";
$password = "960708017149";
$dbname = "u156995236_vip";
mysql_connect($host,$username,$password) or die(mysql_error());
mysql_select_db($dbname) or die(mysql_error());
?>